import React from "react"
import {AgGridReact} from 'ag-grid-react';

import 'ag-grid-community/styles//ag-grid.css';
import 'ag-grid-community/styles//ag-theme-alpine.css';

const Production=()=>{

  return(<>
    <h1>Production</h1>
  
  
  </>)
}

export default Production