import React from "react"
import {AgGridReact} from 'ag-grid-react';

import 'ag-grid-community/styles//ag-grid.css';
import 'ag-grid-community/styles//ag-theme-alpine.css';

const Accounts=()=>{

  return(<>
    <h1>Account</h1>
  
  
  </>)
}

export default Accounts